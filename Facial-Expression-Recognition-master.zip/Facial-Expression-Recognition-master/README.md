# Facial-Expression-Recognition
Training FER+, accuracy is 81%
